# Protótipo SIA Javascript React Front-End

O protótipo tem como objetivo possibilitar uma interface simples de interação com a calculadora de Nível de Maturidade.

É feito uma somatória de pontos baseado nas respostas (cada uma com um determinado peso - grau de importância) e com isso calculado o grau aproximado de maturidade da sua organização.

Sendo essa apenas uma das partes da solução final.
